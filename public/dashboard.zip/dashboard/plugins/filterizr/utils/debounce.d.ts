/**
 * Debounce of Underscore.js
 */
export declare const debounce: (func: Function, wait: number, immediate: boolean) => Function;
