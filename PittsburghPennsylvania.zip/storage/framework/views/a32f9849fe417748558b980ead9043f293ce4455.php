<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="card card-dark mt-5">
            <div class="card-header">
                <h6 class=""><?php echo e(__('dashboard_layout.create_topic')); ?></h6>
            </div>
            <!-- /.card-header -->
            <!-- form start -->

            <button type="button" class="btn btn-success m-3" id="add">+</button>


            <form role="form" action="<?php echo e(route('dashboard.gestes.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e($trailer_id); ?>" name="trailer_id">
                <input type="hidden" value="<?php echo e(old('index_val')); ?>" id="index" name="index_val">
                <div class="card-body" id="gestes">
                    
                    <div class="form-group">
                        <div class="form-row">
                            <div class="col">
                                <label for="guest_name_0">اسم الضيف <span class="text-danger">*</span></label>
                                <input id="guest_name_0" name="name[]"
                                       class="form-control mb-3 <?php $__errorArgs = ['name.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       placeholder="" value="<?php echo e(old('name.0')); ?>">
                            </div>

                            <div class="col">
                                <label for="twitter_0">Twitter</label>
                                <input id="twitter_0" type="text" name="twitter[]"
                                       class="form-control mb-3 <?php $__errorArgs = ['twitter.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       placeholder="" value="<?php echo e(old('twitter.0')); ?>">
                            </div>
                            <div class="col">
                                <label for="facebook_0">Facebook</label>
                                <input id="facebook_0" type="text" name="facebook[]"
                                       class="form-control mb-3 <?php $__errorArgs = ['facebook.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       placeholder="" value="<?php echo e(old('facebook.0')); ?>">
                            </div>

                            <div class="col">
                                <label for="instagram_0">Instagram</label>
                                <input id="instagram_0" type="text" name="instagram[]"
                                       class="form-control mb-3 <?php $__errorArgs = ['instagram.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       placeholder="" value="<?php echo e(old('instagram.0')); ?>">
                            </div>

                        </div>
                    </div>


                    <div class="form-group">
                        <div class="form-row">
                            <div class="col">
                                <label for="snapchat_0">Snapchat</label>
                                <input id="snapchat_0" type="text"
                                       class="form-control mb-3 <?php $__errorArgs = ['snapchat.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       placeholder="" name="snapchat[]" value="<?php echo e(old('snapchat.0')); ?>">
                            </div>

                            <div class="col">
                                <label for="desc_0">اضافة وصف قصير للضيف</label>
                                <textarea name="desc[]" class="form-control <?php $__errorArgs = ['desc.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="2"
                                          id="desc_0"><?php echo e(old('desc.0')); ?></textarea>
                            </div>

                            <div class="col">
                                <label for="web_site_0">Web Site</label>
                                <input id="web_site_0" type="text" name="web[]"
                                       class="form-control mb-3 <?php $__errorArgs = ['web.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       placeholder="" value="<?php echo e(old('web.0')); ?>">
                            </div>
                        </div>
                    </div>


                    <div class="form-group mt-4 text-center">
                        <div class="form-row">
                            <div class="col">
                                <div class="form-group form-check mt-4">
                                    <input name="main[]" value="1" type="checkbox" class="form-check-input" id="gestes_0">
                                    <label for="gestes_0"
                                           class="form-check-label"><?php echo e(__('dashboard_layout.honor_guest')); ?></label>
                                </div>
                            </div>

                            <div class="col">
                                <label for="file_0" class="form-check-label <?php $__errorArgs = ['file.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">اختار صورة شخصية للضيف</label>
                                <input class="mt-3" type="file" name="file[]" value="<?php echo e(old('file.0')); ?>" id="file_0">
                            </div>
                        </div>
                    </div>
                    <hr style="border: none;background: #ccc;color:#ccc;height: 3px">


                    <?php for($i = 1; $i <= old('index_val'); $i++): ?>
                        <div class="form-group">
                            <div class="form-row">
                                <div class="col">
                                    <label for="guest_name_<?php echo e($i); ?>">اسم الضيف <span class="text-danger">*</span></label>
                                    <input id="guest_name_<?php echo e($i); ?>" name="name[]"
                                           class="form-control mb-3 <?php $__errorArgs = ['name.'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="" value="<?php echo e(old('name.'.$i)); ?>">
                                </div>

                                <div class="col">
                                    <label for="twitter_<?php echo e($i); ?>">Twitter</label>
                                    <input id="twitter_<?php echo e($i); ?>" type="text" name="twitter[]"
                                           class="form-control mb-3 <?php $__errorArgs = ['twitter.'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="" value="<?php echo e(old('twitter.'.$i)); ?>">
                                </div>
                                <div class="col">
                                    <label for="facebook_<?php echo e($i); ?>">Facebook</label>
                                    <input id="facebook_<?php echo e($i); ?>" type="text" name="facebook[]"
                                           class="form-control mb-3 <?php $__errorArgs = ['facebook.'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="" value="<?php echo e(old('facebook.'.$i)); ?>">
                                </div>

                                <div class="col">
                                    <label for="instagram_<?php echo e($i); ?>">Instagram</label>
                                    <input id="instagram_<?php echo e($i); ?>" type="text" name="instagram[]"
                                           class="form-control mb-3 <?php $__errorArgs = ['instagram.'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="" value="<?php echo e(old('instagram.'.$i)); ?>">
                                </div>

                            </div>
                        </div>


                        <div class="form-group">
                            <div class="form-row">
                                <div class="col">
                                    <label for="snapchat_<?php echo e($i); ?>">Snapchat</label>
                                    <input id="snapchat_<?php echo e($i); ?>" type="text"
                                           class="form-control mb-3 <?php $__errorArgs = ['snapchat.'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="" name="snapchat[]" value="<?php echo e(old('snapchat.'.$i)); ?>">
                                </div>

                                <div class="col">
                                    <label for="desc_<?php echo e($i); ?>">اضافة وصف قصير للضيف</label>
                                    <textarea name="desc[]" class="form-control <?php $__errorArgs = ['desc.'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="2"
                                              id="desc_<?php echo e($i); ?>"><?php echo e(old('desc.'.$i)); ?></textarea>
                                </div>

                                <div class="col">
                                    <label for="web_site_<?php echo e($i); ?>">Web Site</label>
                                    <input id="web_site_<?php echo e($i); ?>" type="text" name="web[]"
                                           class="form-control mb-3 <?php $__errorArgs = ['web.'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="" value="<?php echo e(old('web.'.$i)); ?>">
                                </div>
                            </div>
                        </div>


                        <div class="form-group mt-4 text-center">
                            <div class="form-row">
                                <div class="col">
                                    <div class="form-group form-check mt-4">
                                        <input name="main[]" value="1" type="checkbox" class="form-check-input" id="gestes_<?php echo e($i); ?>">
                                        <label for="gestes_<?php echo e($i); ?>"
                                               class="form-check-label"><?php echo e(__('dashboard_layout.honor_guest')); ?></label>
                                    </div>
                                </div>

                                <div class="col">
                                    <label for="file_<?php echo e($i); ?>" class="form-check-label <?php $__errorArgs = ['file.'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">اختار صورة شخصية للضيف</label>
                                    <input class="mt-3 <?php $__errorArgs = ['file.'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('file'.$i)); ?>" type="file" name="file[]" id="file_<?php echo e($i); ?>">
                                </div>

                                <div class="col">
                                    <div class="col">
                                        <button type="button" onclick="del(<?php echo e($i); ?>)" class="btn btn-dark w-100">-
                                        </button>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <hr style="border: none;background: #ccc;color:#ccc;height: 3px">
                    <?php endfor; ?>







                </div>






                <div class="container mb-3">
                    <div class="progress">
                        <div class="progress-bar bg-dark" role="progressbar" style="width: 50%" aria-valuenow="50"
                             aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                    <button type="submit" class="btn btn-dark">التالي</button>
                </div>
            </form>
        </div>
        <!-- /.card -->
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
    <script>
        let count = 0 ? count = 0 : $('#index').val();
        $(document).ready(function () {
            $('#add').click(function () {
                count++
                $('#index').val(count)
                $('#gestes').append(`
                <div id="item-${count}">
                <div class="form-group">
                        <div class="form-row">
                            <div class="col">
                                <label for="guest_name_${count}">اسم الضيف <span class="text-danger">*</span></label>
                                <input id="guest_name_${count}" name="name[]"
                                       class="form-control mb-3
                                       placeholder="">
                            </div>

                            <div class="col">
                                <label for="twitter_${count}">Twitter</label>
                                <input id="twitter_${count}" type="text" name="twitter[]"
                                       class="form-control mb-3"
                                       placeholder="">
                            </div>
                            <div class="col">
                                <label for="facebook_${count}">Facebook</label>
                                <input id="facebook_${count}" type="text" name="facebook[]"
                                       class="form-control mb-3"
                                       placeholder="">
                            </div>

                            <div class="col">
                                <label for="instagram_${count}">Instagram</label>
                                <input id="instagram_${count}" type="text" name="instagram[]"
                                       class="form-control mb-3"
                                       placeholder="">
                            </div>

                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-row">
                            <div class="col">
                                <label for="snapchat_${count}">Snapchat</label>
                                <input id="snapchat_${count}" type="text"
                                       class="form-control mb-3"
                                       placeholder="" name="snapchat[]">
                            </div>

                            <div class="col">
                                <label for="desc_${count}">اضافة وصف قصير للضيف</label>
                                <textarea name="desc[]" class="form-control" rows="2"
                                          id="desc_${count}"></textarea>
                            </div>

                            <div class="col">
                                <label for="web_site_${count}">Web Site</label>
                                <input id="web_site_${count}" type="text" name="web[]"
                                       class="form-control mb-3"
                                       placeholder="">
                            </div>
                        </div>
                    </div>


                    <div class="form-group mt-4 text-center">
                        <div class="form-row">
                            <div class="col">
                                <div class="form-group form-check mt-4">
                                    <input name="main[]" value="1" type="checkbox" class="form-check-input" id="gestes_${count}">
                                    <label for="gestes_${count}"
                                           class="form-check-label"><?php echo e(__('dashboard_layout.honor_guest')); ?></label>
                                </div>
                            </div>

                            <div class="col">
                                <label for="file_${count}" class="form-check-label">اختار صورة شخصية للضيف</label>
                                <input class="mt-3" name="file[]" type="file" id="file_${count}">
                            </div>

                            <div class="col">
                                <div class="form-group" style="margin-top: 30px">
                                    <div class="col">
                                        <button type="button" onclick="del(${count})" class="btn btn-dark w-100">-
                                        </button>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <hr style="border: none;background: #ccc;color:#ccc;height: 3px">
                </div>
                </div>
                `)
            })
        })
        function del(i) {
            $(`#item-${i}`).remove();
            count--
            $('#index').val(count)
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.index.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abood\Desktop\PittsburghPennsylvania\resources\views/dashboard/guests/create.blade.php ENDPATH**/ ?>