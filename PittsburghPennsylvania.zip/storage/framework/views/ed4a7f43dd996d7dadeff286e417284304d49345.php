<?php $__env->startSection('style'); ?>

    <style>
        td , th{
            text-align: center;
        }
    </style>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>


    <div class="container">
        <div class="card card-primary mt-5">
            <div class="card-header">
                <h6 class=""><?php echo e(__('dashboard_layout.slider')); ?></h6>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form role="form" action="<?php echo e(route('dashboard.slider.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="form-group">
                        <label for="title"><?php echo e(__('dashboard_layout.title')); ?></label>
                        <input type="text" class="form-control" name="title" id="title" placeholder="<?php echo e(__('dashboard_layout.title')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="desc"><?php echo e(__('dashboard_layout.desc')); ?></label>
                        <textarea class="form-control" name="desc" id="desc" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputFile"><?php echo e(__('dashboard_layout.img')); ?></label>
                        <div class="input-group">
                            <div class="custom-file">
                                <input type="file" name="img">
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">رفع الصورة</button>
                </div>
            </form>
        </div>
        <!-- /.card -->


        <table class="table table-dark">
            <thead>
            <tr>
                <th scope="col">العنوان</th>
                <th scope="col">الوصف</th>
                <th scope="col">معاينة</th>
                <th scope="col"></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i->title); ?></td>
                <td><?php echo e($i->desc); ?></td>
                <td>
                    <img src="<?php echo e($i->img_url); ?>" width="200" height="80">
                </td>
                <td>
                    <a href="<?php echo e(route('dashboard.slider.delete' , ['id' => $i->id])); ?>" style="font-size: 30px" class="text-success"><i class="far fa-edit"></i></a>
                </td>
                <td>
                    <a href="<?php echo e(route('dashboard.slider.delete' , ['id' => $i->id])); ?>" style="font-size: 30px" class="text-danger"><i class="fas fa-trash"></i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.index.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abood\Desktop\PittsburghPennsylvania\resources\views/dashboard/slider/create.blade.php ENDPATH**/ ?>