<?php $__env->startSection('style'); ?>

    <style>
        th , td {text-align: center}
    </style>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card card-success mt-5">
            <div class="card-header">
                <h6 class=""><?php echo e(__('dashboard_layout.footer_social_links')); ?></h6>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form role="form" action="<?php echo e(route('dashboard.footer_social_links.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body">

                    <div class="alert alert-warning">
                        <a href="https://fontawesome.com/" class="text-white">fontawesome </a>
                    </div>

                    <div class="form-group">
                        <label for="select_domain">حدد النطاق السابق</label>
                        <select class="form-control" id="select_domain" onchange="getType()">
                            <option value="">ححد النطاق السابق</option>
                            <?php $__currentLoopData = $footerLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option><?php echo e($i->type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="type"><?php echo e(__('dashboard_layout.type_social')); ?></label>
                        <input type="text" class="form-control <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="type" id="type" placeholder="youtube,facebook,...">
                    </div>


                    <div class="form-group">
                        <label for="icon">icon</label>
                        <input type="text" class="form-control  <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="icon" id="icon" placeholder="icon from fontawesome">
                    </div>

                    <div class="form-group">
                        <label for="color">icon color</label>
                        <input type="color" name="color" id="color">
                    </div>

                    <div class="form-group">
                        <label for="title"><?php echo e(__('dashboard_layout.title')); ?></label>
                        <input dir="rtl" type="text" class="form-control  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title" id="title" placeholder="<?php echo e(__('dashboard_layout.title')); ?>">
                    </div>


                    <div class="form-group">
                        <label for="link"><?php echo e(__('dashboard_layout.link')); ?></label>
                        <input dir="rtl" type="text" class="form-control  <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="link" id="link" placeholder="<?php echo e(__('dashboard_layout.link')); ?>">
                    </div>

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">حفظ أوتحديث</button>
                </div>
            </form>
        </div>
        <!-- /.card -->


        <table class="table table-dark">
            <thead>
            <tr>
                <th scope="col">العنوان</th>
                <th scope="col">النوع</th>
                <th scope="col">الرابط</th>
                <th scope="col"></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $footerLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i->title); ?></td>
                    <td><?php echo e($i->type); ?></td>
                    <td><?php echo e($i->link); ?></td>
                    <td>
                        <a href="<?php echo e(route('dashboard.footer_social_links.delete' , ['id' => $i->id])); ?>" style="font-size: 30px" class="text-danger"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>


<script>
    function getType()
    {
       type = document.getElementById('select_domain').value

        document.getElementById('type').value = type

    }


</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.index.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abood\Desktop\PittsburghPennsylvania\resources\views\dashboard\footer\create.blade.php ENDPATH**/ ?>