<?php $__env->startSection('content'); ?>


    <div class="container">
        <div class="card card-primary mt-5">
            <div class="card-header">
                <h6 class=""><?php echo e(__('dashboard_layout.volunteers')); ?></h6>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form role="form" action="<?php echo e(route('dashboard.volunteer.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="form-group">
                        <label for="name"><?php echo e(__('dashboard_layout.volunteer_name')); ?></label>
                        <input type="text" class="form-control" name="name" id="name" placeholder="<?php echo e(__('dashboard_layout.volunteer_name')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="desc"><?php echo e(__('dashboard_layout.desc')); ?></label>
                        <textarea class="form-control" name="desc" id="desc" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="img_url"><?php echo e(__('dashboard_layout.img')); ?></label>
                        <div class="input-group">
                            <div class="custom-file">
                                <input type="file" name="img">
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">حفظ</button>
                </div>
            </form>
        </div>
    </div>
        <!-- /.card -->






<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.index.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abood\Desktop\PittsburghPennsylvania\resources\views\dashboard\volunteer\create.blade.php ENDPATH**/ ?>