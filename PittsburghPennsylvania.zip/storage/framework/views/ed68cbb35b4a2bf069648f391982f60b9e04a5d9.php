<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $iframe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row bg-white mt-3 card-body rounded">
        <div class="col-lg-6">
            <iframe width="98%" height="315" src="https://www.youtube.com/embed/<?php echo e($y->url_id); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
        <div class="col-lg-6 mt-3">
            <a target="_blank" href="https://www.youtube.com/watch?v=<?php echo e($y->url_id); ?>"><?php echo e(Youtube::getVideoInfo('iLnYGAzxd9o')->snippet->title); ?></a>
            <hr>
            <p>
                <?php echo $y->desc; ?>

            </p>
            <div>
                <span class="font-weight-bold">احصائية الفديو:</span>
                <table style="width: 100%" class="mt-2">
                    <tr>
                        <th class="text-warning">المشاهدات</th>
                        <th class="text-success">الاعجابات</th>
                        <th class="text-secondary">غير معجب</th>
                    </tr>
                    <tr>
                        <td><?php echo e(Youtube::getVideoInfo($y->url_id)->statistics->viewCount); ?></td>
                        <td><?php echo e(Youtube::getVideoInfo($y->url_id)->statistics->likeCount); ?></td>
                        <td><?php echo e(Youtube::getVideoInfo($y->url_id)->statistics->dislikeCount); ?></td>
                    </tr>
                </table>
                <a href="<?php echo e(route('topic.index' , ['slug' => $y->slug])); ?>" title="<?php echo e($y->title); ?>">إقرأ المزيد ...</a>
            </div>
        </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="container d-flex justify-content-center mt-3">
        <?php echo $iframe->links(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.landing-page.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abood\Desktop\PittsburghPennsylvania\resources\views/web/youtube/index.blade.php ENDPATH**/ ?>