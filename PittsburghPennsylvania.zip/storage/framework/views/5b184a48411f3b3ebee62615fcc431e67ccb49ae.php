<!doctype html>
<html dir="rtl" lang="ar">
<head>
     <?php if (isset($component)) { $__componentOriginalc49adecc4ce1fd027d2be1058cd7de13090b81cd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Index\Head::class, []); ?>
<?php $component->withName('index.head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc49adecc4ce1fd027d2be1058cd7de13090b81cd)): ?>
<?php $component = $__componentOriginalc49adecc4ce1fd027d2be1058cd7de13090b81cd; ?>
<?php unset($__componentOriginalc49adecc4ce1fd027d2be1058cd7de13090b81cd); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <link href="https://fonts.googleapis.com/css2?family=Changa:wght@500&display=swap" rel="stylesheet">

    <link href="/css/style.css" rel="stylesheet" type="text/css" media="all" />

    <style>
        body{font-family: 'Mada', sans-serif;background-color: #dfe6e9}
        .main {
            font-size: 20px;text-align: justify;line-height: 2.5;padding: 0 160px 0 160px
        }
        .references{
            padding: 0 160px 75px 160px;
        }
        @media  only screen and (max-width: 990px) {
            .main {
                padding: 13px;
                line-height: 1.3;
            }
            .references {
                padding: 0;
                font-size: 16px;

            }

        }

    </style>
</head>
<body>
 <?php if (isset($component)) { $__componentOriginal07d62586f47a39d2ca839c39ec133421cb0ce29d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Index\Navbar::class, []); ?>
<?php $component->withName('index.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal07d62586f47a39d2ca839c39ec133421cb0ce29d)): ?>
<?php $component = $__componentOriginal07d62586f47a39d2ca839c39ec133421cb0ce29d; ?>
<?php unset($__componentOriginal07d62586f47a39d2ca839c39ec133421cb0ce29d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 






<div class="container">

    <?php if($trailer->url_id == !null): ?>
    <div class="row d-flex justify-content-center mt-4 ">
        <div class="col-lg-7 text-center">
            <iframe width="100%" height="350" src="https://www.youtube.com/embed/<?php echo e($trailer->url_id); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
    </div>
    <?php endif; ?>

    <!--    <div class="container mt-4">-->
    <!--        <div class="row mt-2">-->
    <!--            <div class="col-lg-12 text-center font-weight-bold ">-->
    <!--                <p class="text-justify">-->
    <!--                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut consectetur cupiditate enim hic inventore nam nisi! Aspernatur fuga laudantium natus nemo pariatur quibusdam quod. Ab culpa, dignissimos excepturi fugit libero maiores natus odio perferendis porro praesentium quibusdam, recusandae temporibus tenetur vero voluptatem! Alias doloribus eius perferendis perspiciatis placeat reiciendis sint! At atque aut, autem consectetur, corporis delectus dolores dolorum esse excepturi fuga in ipsum libero maiores nam natus necessitatibus nostrum omnis perspiciatis porro quidem quis ratione reprehenderit sunt temporibus tenetur veritatis voluptate voluptatibus. Animi eaque labore, pariatur repellat sapiente velit?-->
    <!--                </p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->

    <!--    <div class="row d-flex justify-content-center mt-2">-->
    <!--        <div class="col-lg-5">-->
    <!--            <div class="d-flex justify-content-center" style="height: 2px;background-color: #d5ca99"></div>-->

    <!--        </div>-->
    <!--    </div>-->
    <div class="container-fluid">


        <div class="row mt-3" style="border: #d5ca99 solid 1px;">
            <div class="col-lg-12 bg-white">
                <p class="text-center font-weight-bold mt-5 mb-3" style="font-size: 20px"><?php echo e($trailer->title); ?></p>

                <p class="main text-justify mt-4" style="font-size: 15px">
                    <?php echo e($trailer->desc); ?>

                </p>
                <?php if($topic->type == 'y'): ?>
                <iframe width="100%" height="340" src="https://www.youtube.com/embed/<?php echo e($topic->url_id); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                <?php endif; ?>
                <p class="main">
                    <?php echo e($topic->desc); ?>

                </p>

                <p style="font-size: 20px;font-family: 'Changa', sans-serif;" class="main text-center mt-5">الضيف</p>

                <div class="testimonials" style="padding: 5px">
                    <div class="container">
                        <div class="phpkida_testimonials_grids">
                            <section class="center slider">
                                <div class="agileits_testimonial_grid">
                                    <div class="pk_testimonial_grid ">
                                        <p class="">Awesome services, i am happy to here becouse of your services. in future i will contine.</p>
                                        <h4>Mukesh Jakhar</h4>
                                        <h5>Developer</h5>
                                        <div class="pk_testimonial_grid_pos">
                                            <img src="images/1.jpg" alt=" " class="img-responsive" />
                                        </div>
                                    </div>
                                </div>


                            </section>
                        </div>
                    </div>
                </div>
                <hr>

                <p style="font-size: 20px;font-family: 'Changa', sans-serif;" class="main text-center mt-5">ضيوف الشرف</p>
                <!-- testimonials -->
                <div class="testimonials mb-5" style="padding: 5px">
                    <div class="container">
                        <div class="phpkida_testimonials_grids">
                            <section class="center slider">
                                <div class="agileits_testimonial_grid">
                                    <div class="pk_testimonial_grid">
                                        <p>Awesome services, i am happy to here becouse of your services. in future i will contine.</p>
                                        <h4>Mukesh Jakhar</h4>
                                        <h5>Developer</h5>
                                        <div class="pk_testimonial_grid_pos">
                                            <img src="images/1.jpg" alt=" " class="img-responsive" />
                                        </div>
                                    </div>
                                </div>
                                <div class="agileits_testimonial_grid">
                                    <div class="pk_testimonial_grid">
                                        <p>Awesome services, i am happy to here becouse of your services. in future i will contine.</p>
                                        <div class="row text-center d-flex justify-content-center">
                                            <div class="col-2" style="font-size: 30px"><i class="fab fa-facebook"></i></div>
                                            <div class="col-2">d</div>
                                            <div class="col-2">d</div>
                                            <div class="col-2">d</div>
                                        </div>
                                        <h4>Shivani Gupta</h4>
                                        <h5>Designer</h5>
                                        <div class="pk_testimonial_grid_pos">
                                            <img src="images/2.jpg" alt=" " class="img-responsive" />
                                        </div>
                                    </div>
                                </div>
                                <div class="agileits_testimonial_grid">
                                    <div class="pk_testimonial_grid">
                                        <p>IAwesome services, i am happy to here becouse of your services. in future i will contine.</p>
                                        <h4>Michael DoeMukesh Jakhar</h4>
                                        <h5>Developer</h5>
                                        <div class="pk_testimonial_grid_pos">
                                            <img src="images/1.jpg" alt=" " class="img-responsive" />
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
                <!-- //testimonials -->




                <!--<div class="container references">-->
                <!--    <div style="font-size: 20px;text-align: justify;line-height: 3;">-->
                <!--        الحسابات:-->
                <!--        <ul>-->
                <!--            <li style="list-style: none"><span style="color: #535318">@Rebdis  — حساب عبدالله الربدي</span> على تويتر</li>-->
                <!--            <li style="list-style: none"><span style="color: #535318">@Rebdis  — حساب عبدالله الربدي</span> على تويتر</li>-->
                <!--            <li style="list-style: none"><span style="color: #535318">@Rebdis  — حساب عبدالله الربدي</span> على تويتر</li>-->
                <!--            <li style="list-style: none"><span style="color: #535318">@Rebdis  — حساب عبدالله الربدي</span> على تويتر</li>-->


                <!--        </ul>-->
                <!--    </div>-->
                <!--</div>-->
            </div>
        </div>
        <br>
    </div>

</div>


 <?php if (isset($component)) { $__componentOriginalf3feb0b13cd9a731eaa60d23fe8c319dc1114fc3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Index\Footer::class, []); ?>
<?php $component->withName('index.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf3feb0b13cd9a731eaa60d23fe8c319dc1114fc3)): ?>
<?php $component = $__componentOriginalf3feb0b13cd9a731eaa60d23fe8c319dc1114fc3; ?>
<?php unset($__componentOriginalf3feb0b13cd9a731eaa60d23fe8c319dc1114fc3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</body>
</html>
<?php /**PATH C:\Users\Abood\Desktop\PittsburghPennsylvania\resources\views\web\topics\index.blade.php ENDPATH**/ ?>