<?php $__env->startSection('content'); ?>

    <div class="container">
        <br><br>

        <div class="card card-dark">
            <div class="card-header">
                <h6 class="">روابط موضوع(<?php echo e(\App\Models\Trailer::find($trailer_id)->title); ?>)</h6>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <button type="button" class="btn btn-success m-3" id="add">+</button>
            <form role="form" action="<?php echo e(route('dashboard.trailerLinks.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e(old('index_val')); ?>" id="index" name="index_val">
                <input type="hidden" value="<?php echo e($trailer_id); ?>" name="trailer_id">
                <div class="form-group m-3" id="item">
                    <div class="form-row">
                        <div class="col">
                            <label for="title_0">العنوان<span class="text-danger">*</span></label>
                            <input name="title[]" type="text" class="form-control <?php $__errorArgs = ['title.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title_0">
                        </div>

                        <div class="col">
                            <label for="link">الرابط<span class="text-danger">*</span></label>
                            <input name="link[]" type="text" class="form-control <?php $__errorArgs = ['link.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="link">
                        </div>
                    </div>

                    <?php for($i = 1; $i <= old('index_val'); $i++): ?>
                        <div class="form-row mt-3" id="del_item_<?php echo e($i); ?>">
                            <div class="col">
                                <label for="title_<?php echo e($i); ?>">العنوان<span class="text-danger">*</span></label>
                                <input name="title[]" type="text" class="form-control <?php $__errorArgs = ['title.'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title_<?php echo e($i); ?>">
                            </div>
                            <div class="col">
                                <label for="link_<?php echo e($i); ?>">الرابط<span class="text-danger">*</span></label>
                                <input name="link[]" type="text" class="form-control <?php $__errorArgs = ['link.'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="link_<?php echo e($i); ?>">
                            </div>
                            <div class="col-2" style="margin-top: 30px">
                                <button type="button" onclick="del(<?php echo e($i); ?>)" class="btn btn-dark"><i
                                        class="fas fa-minus"></i></button>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>




                <div class="card-footer">
                    <button type="submit" class="btn btn-dark">إنهاء</button>
                </div>
            </form>
        </div>
        <!-- /.card -->

    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
    <script>
        let count = 0 ? count = 0 : $('#index').val();
        $(document).ready(function () {
            $('#add').click(function () {
                count++
                console.log(count)
                $('#index').val(count)
                $('#item').append(`
                        <div class="form-row mt-3" id="del_item_${count}">
                            <div class="col">
                                <label for="title_${count}">العنوان<span class="text-danger">*</span></label>
                                <input name="title[]" type="text" class="form-control" id="title_${count}">
                            </div>

                            <div class="col">
                                <label for="link_${count}">الرابط<span class="text-danger">*</span></label>
                                <input name="link[]" type="text" class="form-control" id="link_${count}">
                            </div>
                            <div class="col-2" style="margin-top: 30px">
                                <button type="button" onclick="del(${count})" class="btn btn-dark"><i class="fas fa-minus"></i></button>
                            </div>
                        </div>



                `)
            })



        })
        function del(i) {
            $(`#del_item_${i}`).remove();
            count--
            $('#index').val(count)
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.index.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abood\Desktop\PittsburghPennsylvania\resources\views\dashboard\trailers\trailer-links\create.blade.php ENDPATH**/ ?>