<!doctype html>
<html dir="rtl" lang="ar">
<head>
     <?php if (isset($component)) { $__componentOriginalc49adecc4ce1fd027d2be1058cd7de13090b81cd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Index\Head::class, []); ?>
<?php $component->withName('index.head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc49adecc4ce1fd027d2be1058cd7de13090b81cd)): ?>
<?php $component = $__componentOriginalc49adecc4ce1fd027d2be1058cd7de13090b81cd; ?>
<?php unset($__componentOriginalc49adecc4ce1fd027d2be1058cd7de13090b81cd); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <link href="https://fonts.googleapis.com/css2?family=Changa:wght@500&display=swap" rel="stylesheet">

    <link href="/css/style.css" rel="stylesheet" type="text/css" media="all" />

    <style>
        body{font-family: 'Mada', sans-serif;background-color: #dfe6e9}
        .main {
            font-size: 18px;text-align: justify;line-height: 2.5;padding: 0 160px 0 160px;margin-top: 15px;
        }
        .references{
            padding: 0 160px 75px 160px;
        }
        @media  only screen and (max-width: 990px) {
            .main {
                padding: 13px;
                line-height: 1.3;
            }
            .references {
                padding: 0;
                font-size: 16px;

            }

        }

    </style>
</head>
<body>
 <?php if (isset($component)) { $__componentOriginal07d62586f47a39d2ca839c39ec133421cb0ce29d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Index\Navbar::class, []); ?>
<?php $component->withName('index.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal07d62586f47a39d2ca839c39ec133421cb0ce29d)): ?>
<?php $component = $__componentOriginal07d62586f47a39d2ca839c39ec133421cb0ce29d; ?>
<?php unset($__componentOriginal07d62586f47a39d2ca839c39ec133421cb0ce29d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 






<div class="container">

    <?php if($trailer->url_id == !null): ?>
    <div class="row d-flex justify-content-center mt-4 ">
        <div class="col-lg-7 text-center">
            <iframe width="100%" height="350" src="https://www.youtube.com/embed/<?php echo e($trailer->url_id); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
    </div>
        <h4 class="text-center font-weight-bold"><?php echo e($trailer->title); ?></h4>











<?php endif; ?>



        <div class="row d-flex justify-content-center mt-2">
            <div class="col-lg-5">
                <div class="d-flex justify-content-center" style="height: 2px;background-color: #d5ca99"></div>
            </div>
        </div>
    <div class="container-fluid">


        <div class="row mt-3" style="border: #d5ca99 solid 1px;">
            <div class="col-lg-12 bg-white">






                <div class="mt-5">
                <?php $__currentLoopData = $iframes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($i->type == 'y'): ?>
                <iframe width="100%" height="340" src="https://www.youtube.com/embed/<?php echo e($i->url_id); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <div class="row justify-content-center">
                <?php $__currentLoopData = $iframes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($i->type == 't'): ?>
                        <div class="col-lg-6">
                            <?php echo $i->iframe; ?>

                        </div>
                     <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>


                <div class="row justify-content-center">
                    <?php $__currentLoopData = $iframes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($i->type == 'p'): ?>
                            <div class="col-lg-6">
                                <?php echo $i->iframe; ?>

                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                </div>

                <div class="main">
                    <?php echo $topic->desc; ?>

                </div>

                <?php if($gestesManin->count() == 1): ?>
                    <p style="font-size: 20px;font-family: 'Changa', sans-serif;" class="main text-center mt-5">المتحدث</p>
                <?php elseif($gestesManin->count() > 1): ?>
                    <p style="font-size: 20px;font-family: 'Changa', sans-serif;" class="main text-center mt-5">المتحدثون</p>
                <?php endif; ?>

                <div class="testimonials" style="padding: 5px">
                    <div class="container">
                    <?php $__currentLoopData = $gestesManin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="phpkida_testimonials_grids">
                            <section class="center slider">
                                <div class="agileits_testimonial_grid">
                                    <div class="pk_testimonial_grid">
                                        <p class=""><?php echo e($i->desc); ?></p>
                                        <div class="row text-center d-flex justify-content-center">
                                            <?php if($i->twitter == !null): ?>
                                                <div class="col-2" style="font-size: 30px">
                                                    <a target="_blank" href="<?php echo e($i->twitter); ?>" class="text-info">
                                                        <i class="fab fa-twitter"></i>
                                                    </a>
                                                </div>
                                            <?php endif; ?>

                                                <?php if($i->facebook == !null): ?>
                                                    <div class="col-2" style="font-size: 30px">
                                                        <a target="_blank" href="<?php echo e($i->facebook); ?>" class="text-primary">
                                                            <i class="fab fa-facebook"></i>
                                                        </a>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($i->youtube == !null): ?>
                                                    <div class="col-2" style="font-size: 30px">
                                                        <a target="_blank" href="<?php echo e($i->youtube); ?>" class="text-danger">
                                                            <i class="fab fa-youtube"></i>
                                                        </a>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($i->instagram == !null): ?>
                                                    <div class="col-2" style="font-size: 30px">
                                                        <a target="_blank" href="<?php echo e($i->instagram); ?>" style="color: brown;">
                                                            <i class="fab fa-instagram"></i>
                                                        </a>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($i->snapchat == !null): ?>
                                                    <div class="col-2" style="font-size: 30px">
                                                        <a target="_blank" href="<?php echo e($i->snapchat); ?>" class="text-warning">
                                                            <i class="fab fa-snapchat"></i>
                                                        </a>
                                                    </div>
                                                <?php endif; ?>
                                        </div>
                                        <h4><?php echo e($i->name); ?></h4>
                                        <div class="pk_testimonial_grid_pos">
                                            <?php if($i->img_url != null): ?>
                                            <img src="<?php echo e($i->img_url); ?>" width="100" height="100" alt="<?php echo e($i->name); ?>" style="cursor: pointer" data-toggle="modal" data-target="#img_po" data-path="<?php echo e($i->img_url); ?>" data-name="<?php echo e($i->name); ?>" class="img-responsive" />
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>


                <?php if($gestesUnMane->count() == 1): ?>
                    <hr>
                <p style="font-size: 20px;font-family: 'Changa', sans-serif;" class="main text-center mt-5">الضيف</p>
                <?php elseif($gestesUnMane->count() > 1): ?>
                    <p style="font-size: 20px;font-family: 'Changa', sans-serif;" class="main text-center mt-5">الضيوف</p>
                <?php endif; ?>

                <div class="testimonials" style="padding: 5px">
                    <div class="container mb-5">
                        <?php $__currentLoopData = $gestesUnMane; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="phpkida_testimonials_grids">
                                    <section class="center slider">
                                        <div class="agileits_testimonial_grid">
                                            <div class="pk_testimonial_grid ">
                                                <p class=""><?php echo e($i->desc); ?></p>
                                                <div class="row text-center d-flex justify-content-center">
                                                    <?php if($i->twitter == !null): ?>
                                                        <div class="col-2" style="font-size: 30px">
                                                            <a target="_blank" href="<?php echo e($i->twitter); ?>" class="text-info">
                                                                <i class="fab fa-twitter"></i>
                                                            </a>
                                                        </div>
                                                    <?php endif; ?>

                                                    <?php if($i->facebook == !null): ?>
                                                        <div class="col-2" style="font-size: 30px">
                                                            <a target="_blank" href="<?php echo e($i->facebook); ?>" class="text-primary">
                                                                <i class="fab fa-facebook"></i>
                                                            </a>
                                                        </div>
                                                    <?php endif; ?>

                                                    <?php if($i->youtube == !null): ?>
                                                        <div class="col-2" style="font-size: 30px">
                                                            <a target="_blank" href="<?php echo e($i->youtube); ?>" class="text-danger">
                                                                <i class="fab fa-youtube"></i>
                                                            </a>
                                                        </div>
                                                    <?php endif; ?>

                                                    <?php if($i->instagram == !null): ?>
                                                        <div class="col-2" style="font-size: 30px">
                                                            <a target="_blank" href="<?php echo e($i->instagram); ?>" style="color: brown;">
                                                                <i class="fab fa-instagram"></i>
                                                            </a>
                                                        </div>
                                                    <?php endif; ?>

                                                    <?php if($i->snapchat == !null): ?>
                                                        <div class="col-2" style="font-size: 30px">
                                                            <a target="_blank" href="<?php echo e($i->snapchat); ?>" class="text-warning">
                                                                <i class="fab fa-snapchat"></i>
                                                            </a>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                <h4><?php echo e($i->name); ?></h4>
                                                <div class="pk_testimonial_grid_pos">
                                                    <?php if($i->img_url != null): ?>
                                                    <img src="<?php echo e($i->img_url); ?>" width="100" height="100" alt="<?php echo e($i->name); ?>" style="cursor: pointer" data-toggle="modal" data-target="#img_po" data-path="<?php echo e($i->img_url); ?>" data-name="<?php echo e($i->name); ?>" class="img-responsive" />
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>


                <?php if($links->count() > 0): ?>
                 <hr>
                <div class="container references">
                   <div style="font-size: 20px;text-align: justify;line-height: 3;">
                        الروابط:
                       <ul>
                           <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <li style="list-style: none"><span style="color: #535318"><a target="_blank" title="<?php echo e($link->title); ?>" href="<?php echo e($link->link); ?>"><?php echo e($link->title); ?></a></span></li>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>
        <br>
    </div>

</div>
<div class="modal fade" id="img_po" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="name">New message</h5>



            </div>
            <div class="modal-body">
                <img id="img" height="100%" width="100%">
            </div>
        </div>
    </div>
</div>


 <?php if (isset($component)) { $__componentOriginalf3feb0b13cd9a731eaa60d23fe8c319dc1114fc3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Index\Footer::class, []); ?>
<?php $component->withName('index.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf3feb0b13cd9a731eaa60d23fe8c319dc1114fc3)): ?>
<?php $component = $__componentOriginalf3feb0b13cd9a731eaa60d23fe8c319dc1114fc3; ?>
<?php unset($__componentOriginalf3feb0b13cd9a731eaa60d23fe8c319dc1114fc3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/js/all.min.js" integrity="sha512-YSdqvJoZr83hj76AIVdOcvLWYMWzy6sJyIMic2aQz5kh2bPTd9dzY3NtdeEAzPp/PhgZqr4aJObB3ym/vsItMg==" crossorigin="anonymous"></script>

<script>
    $('#img_po').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget) // Button that triggered the modal
        var path = button.data('path') // Extract info from data-* attributes
        var name = button.data('name') // Extract info from data-* attributes
        // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
        // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
        var modal = $(this)
        modal.find('#img').attr('src' , path)
        modal.find('#name').text(name)
    })

</script>
</body>
</html>
<?php /**PATH C:\Users\Abood\Desktop\PittsburghPennsylvania\resources\views/web/topics/index.blade.php ENDPATH**/ ?>