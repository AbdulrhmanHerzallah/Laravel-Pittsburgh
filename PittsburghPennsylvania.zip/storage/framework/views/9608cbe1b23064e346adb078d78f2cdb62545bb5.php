<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $iframe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row bg-white mt-3 card-body rounded">
            <div class="col-lg-6">
                <?php echo $y->iframe; ?>

            </div>
            <div class="col-lg-6 mt-3 mb-3">
                <h3><?php echo e($y->title); ?></h3>
                <hr>
                <p>
                    <?php echo $y->desc; ?>

                </p>
                <div>
                    <a href="<?php echo e(route('topic.index' , ['slug' => $y->slug])); ?>" title="<?php echo e($y->title); ?>">إقرأ المزيد ...</a>
                </div>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="container d-flex justify-content-center mt-3">
        <?php echo $iframe->links(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.landing-page.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abood\Desktop\PittsburghPennsylvania\resources\views/web/spotify/index.blade.php ENDPATH**/ ?>