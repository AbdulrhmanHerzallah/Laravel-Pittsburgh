<?php $__env->startSection('style'); ?>

    <style>
        .note-btn[aria-label="Picture"] , .note-btn[data-original-title="Font Family"] {
            display: none !important;
        }

        /*.note-editor .btn-toolbar button[data-event="showVideoDialog"] {*/
        /*    display: none !important;*/
        /*}*/
    </style>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

    <div class="container">


        <div class="card card-dark mt-5">
            <div class="card-header">
                <h6 class=""><?php echo e(__('dashboard_layout.create_topic')); ?> (<?php echo e($title); ?>)</h6>
            </div>
            <!-- /.card-header -->
            <!-- form start -->


            <form role="form" action="<?php echo e(route('dashboard.topic.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body">

                    <div class="form-group">
                        <label for="desc"><?php echo e(__('dashboard_layout.desc')); ?></label>

                        <textarea  id="desc" name="desc" class="textarea" placeholder="Place some text here"
                                  style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;z-index: 400"></textarea>

                    </div>

                   <input type="hidden" value="<?php echo e($trailer_id); ?>" name="trailer_id">


                    <div class="container mb-3">
                        <div class="progress">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>

































                </div>

                <!-- /.card-body -->
                <div class="card-footer">
                    <button type="submit"  class="btn btn-dark">التالي</button>
                </div>
            </form>
        </div>
        <!-- /.card -->
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
    <script>
        function selectType()
        {
            let type = document.getElementById('type').value

            if (type == 'y')
            {
                document.getElementById('iframe_twitter').style.display = "none";
                document.getElementById('url_id').style.display = "block";
                document.getElementById('iframe_spotify').style.display = "none";
                document.getElementById('img').style.display = "none";
            }

            if (type == 't')
            {
                document.getElementById('iframe_twitter').style.display = "block";
                document.getElementById('url_id').style.display = "none";
                document.getElementById('iframe_spotify').style.display = "none";
                document.getElementById('img').style.display = "none";
            }

            if (type == 'p')
            {
                document.getElementById('iframe_twitter').style.display = "none";
                document.getElementById('url_id').style.display = "none";
                document.getElementById('iframe_spotify').style.display = "block";
                document.getElementById('img').style.display = "none";
            }
        }
    </script>

    <script>
        $(function () {
            // Summernote
            $('.textarea').summernote({
                height: 300,
            })
        })
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.index.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abood\Desktop\PittsburghPennsylvania\resources\views/dashboard/topics/create.blade.php ENDPATH**/ ?>