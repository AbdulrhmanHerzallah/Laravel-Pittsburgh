<!DOCTYPE html>
<html>
<head>
 <?php if (isset($component)) { $__componentOriginal64b2edba2908a0b8a0a719cefd195e3775f18c88 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\Head::class, []); ?>
<?php $component->withName('dashboard.head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal64b2edba2908a0b8a0a719cefd195e3775f18c88)): ?>
<?php $component = $__componentOriginal64b2edba2908a0b8a0a719cefd195e3775f18c88; ?>
<?php unset($__componentOriginal64b2edba2908a0b8a0a719cefd195e3775f18c88); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php echo $__env->yieldContent('style'); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <!-- Navbar -->
 <?php if (isset($component)) { $__componentOriginalb9de16204ef2e3b084e3b40bd8a903555dceed67 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\Nav::class, []); ?>
<?php $component->withName('dashboard.nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb9de16204ef2e3b084e3b40bd8a903555dceed67)): ?>
<?php $component = $__componentOriginalb9de16204ef2e3b084e3b40bd8a903555dceed67; ?>
<?php unset($__componentOriginalb9de16204ef2e3b084e3b40bd8a903555dceed67); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

    <!-- Main Sidebar Container -->
 <?php if (isset($component)) { $__componentOriginalb140b3a4dfed3e5d7c0d08e1d6a687fcacc1b87f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\Sidebar::class, []); ?>
<?php $component->withName('dashboard.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb140b3a4dfed3e5d7c0d08e1d6a687fcacc1b87f)): ?>
<?php $component = $__componentOriginalb140b3a4dfed3e5d7c0d08e1d6a687fcacc1b87f; ?>
<?php unset($__componentOriginalb140b3a4dfed3e5d7c0d08e1d6a687fcacc1b87f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <!-- Content Wrapper. Contains page content -->



    <div class="content-wrapper">
        <?php echo $__env->yieldContent('content'); ?>
    </div>



 <?php if (isset($component)) { $__componentOriginal72d7129e366ddf7974bb5b3c69851978623afdcb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\Footer::class, []); ?>
<?php $component->withName('dashboard.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal72d7129e366ddf7974bb5b3c69851978623afdcb)): ?>
<?php $component = $__componentOriginal72d7129e366ddf7974bb5b3c69851978623afdcb; ?>
<?php unset($__componentOriginal72d7129e366ddf7974bb5b3c69851978623afdcb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>
<!-- ./wrapper -->


 <?php if (isset($component)) { $__componentOriginald8ede477c6a25e6b7dd6f89255465d825635aacf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\Script::class, []); ?>
<?php $component->withName('dashboard.script'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald8ede477c6a25e6b7dd6f89255465d825635aacf)): ?>
<?php $component = $__componentOriginald8ede477c6a25e6b7dd6f89255465d825635aacf; ?>
<?php unset($__componentOriginald8ede477c6a25e6b7dd6f89255465d825635aacf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

    <?php echo $__env->yieldContent('script'); ?>

</body>
</html>
<?php /**PATH C:\Users\Abood\Desktop\PittsburghPennsylvania\resources\views\dashboard\index\index.blade.php ENDPATH**/ ?>