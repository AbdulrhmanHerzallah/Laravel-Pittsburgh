<!doctype html>
<html dir="rtl" lang="ar">
<head>
  <?php if (isset($component)) { $__componentOriginalc49adecc4ce1fd027d2be1058cd7de13090b81cd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Index\Head::class, []); ?>
<?php $component->withName('index.head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc49adecc4ce1fd027d2be1058cd7de13090b81cd)): ?>
<?php $component = $__componentOriginalc49adecc4ce1fd027d2be1058cd7de13090b81cd; ?>
<?php unset($__componentOriginalc49adecc4ce1fd027d2be1058cd7de13090b81cd); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</head>
<body>
 <?php if (isset($component)) { $__componentOriginal07d62586f47a39d2ca839c39ec133421cb0ce29d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Index\Navbar::class, []); ?>
<?php $component->withName('index.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal07d62586f47a39d2ca839c39ec133421cb0ce29d)): ?>
<?php $component = $__componentOriginal07d62586f47a39d2ca839c39ec133421cb0ce29d; ?>
<?php unset($__componentOriginal07d62586f47a39d2ca839c39ec133421cb0ce29d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<?php if(Request::is('/')): ?>
     <?php if (isset($component)) { $__componentOriginal81fc1d8f3d0bd8ebbc16d1176469792f83dd79e0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Index\Body::class, ['trailer' => $trailer]); ?>
<?php $component->withName('index.body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal81fc1d8f3d0bd8ebbc16d1176469792f83dd79e0)): ?>
<?php $component = $__componentOriginal81fc1d8f3d0bd8ebbc16d1176469792f83dd79e0; ?>
<?php unset($__componentOriginal81fc1d8f3d0bd8ebbc16d1176469792f83dd79e0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php endif; ?>

<div class="container">

</div>

 <?php if (isset($component)) { $__componentOriginalf3feb0b13cd9a731eaa60d23fe8c319dc1114fc3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Index\Footer::class, []); ?>
<?php $component->withName('index.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf3feb0b13cd9a731eaa60d23fe8c319dc1114fc3)): ?>
<?php $component = $__componentOriginalf3feb0b13cd9a731eaa60d23fe8c319dc1114fc3; ?>
<?php unset($__componentOriginalf3feb0b13cd9a731eaa60d23fe8c319dc1114fc3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</body>
</html>
<?php /**PATH C:\Users\Abood\Desktop\PittsburghPennsylvania\resources\views\web\landing-page\index.blade.php ENDPATH**/ ?>