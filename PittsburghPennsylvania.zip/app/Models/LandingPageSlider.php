<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LandingPageSlider extends Model
{
    protected $table = 'landing_page_sliders';

    protected $guarded = [];


}
