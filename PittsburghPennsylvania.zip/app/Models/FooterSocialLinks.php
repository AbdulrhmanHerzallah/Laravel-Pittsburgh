<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FooterSocialLinks extends Model
{
    protected $table = 'footer_social_links';

    protected $guarded = [];

}
