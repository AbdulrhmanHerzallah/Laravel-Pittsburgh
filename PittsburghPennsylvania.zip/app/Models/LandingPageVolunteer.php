<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LandingPageVolunteer extends Model
{
    protected $table = 'landing_page_volunteers';

    protected $guarded = [];

}
